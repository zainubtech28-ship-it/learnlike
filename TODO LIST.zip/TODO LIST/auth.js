// ==========================================
// TASKFLOW AUTHENTICATION JAVASCRIPT
// ==========================================


// ==========================================
// SHOW MESSAGE
// ==========================================

function showMessage(messageText, type) {

    const messageBox =
        document.getElementById("message");

    if (!messageBox) {
        return;
    }

    messageBox.textContent = messageText;

    messageBox.className =
        `message ${type}`;


    // ======================================
    // TIMEOUT CALLBACK
    // Message disappears after 4 seconds
    // ======================================

    setTimeout(() => {

        messageBox.className = "message";

        messageBox.textContent = "";

    }, 4000);

}



// ==========================================
// PASSWORD SHOW / HIDE
// ==========================================

const passwordToggle =
    document.getElementById("passwordToggle");


if (passwordToggle) {

    // ======================================
    // EVENT LISTENER
    // ======================================

    passwordToggle.addEventListener(
        "click",
        function () {

            let passwordInput;


            // Check which page is currently open

            if (
                document.getElementById(
                    "loginPassword"
                )
            ) {

                passwordInput =
                    document.getElementById(
                        "loginPassword"
                    );

            } else {

                passwordInput =
                    document.getElementById(
                        "registerPassword"
                    );

            }


            if (
                passwordInput.type ===
                "password"
            ) {

                passwordInput.type =
                    "text";

                passwordToggle.textContent =
                    "🙈";

            } else {

                passwordInput.type =
                    "password";

                passwordToggle.textContent =
                    "👁";

            }

        }
    );

}



// ==========================================
// REGISTER USER
// ==========================================

const registerForm =
    document.getElementById(
        "registerForm"
    );


if (registerForm) {


    // ======================================
    // EVENT LISTENER
    // Listens for form submit event
    // ======================================

    registerForm.addEventListener(

        "submit",

        async function (event) {


            // Prevent page refresh

            event.preventDefault();



            // Get input values

            const name =
                document
                    .getElementById(
                        "registerName"
                    )
                    .value
                    .trim();


            const email =
                document
                    .getElementById(
                        "registerEmail"
                    )
                    .value
                    .trim()
                    .toLowerCase();


            const password =
                document
                    .getElementById(
                        "registerPassword"
                    )
                    .value;



            // Get button elements

            const registerButton =
                document.getElementById(
                    "registerButton"
                );


            const registerButtonText =
                document.getElementById(
                    "registerButtonText"
                );



            // ==================================
            // VALIDATION
            // ==================================

            if (name.length < 3) {

                showMessage(
                    "Please enter a valid full name.",
                    "error"
                );

                return;

            }


            if (password.length < 6) {

                showMessage(
                    "Password must contain at least 6 characters.",
                    "error"
                );

                return;

            }



            // Disable button while sending data

            registerButton.disabled = true;

            registerButtonText.textContent =
                "Creating Account...";



            try {


                // ==================================
                // SEND DATA TO NODE.JS SERVER
                // ==================================

                const response = await fetch(

                    "/api/register",

                    {

                        method: "POST",


                        headers: {

                            "Content-Type":
                                "application/json"

                        },


                        body: JSON.stringify({

                            name: name,

                            email: email,

                            password: password

                        })

                    }

                );



                // Convert response to JSON

                const data =
                    await response.json();



                // ==================================
                // REGISTRATION FAILED
                // ==================================

                if (!response.ok) {

                    showMessage(

                        data.message
                        ||
                        "Registration failed.",

                        "error"

                    );


                    registerButton.disabled =
                        false;


                    registerButtonText.textContent =
                        "Create Account";


                    return;

                }



                // ==================================
                // REGISTRATION SUCCESSFUL
                // ==================================

                showMessage(

                    "Account created successfully! Redirecting to login...",

                    "success"

                );


                registerForm.reset();



                // ==================================
                // TIMEOUT CALLBACK
                // Redirect after 2 seconds
                // ==================================

                setTimeout(() => {

                    window.location.href =
                        "index.html";

                }, 2000);



            } catch (error) {


                console.error(
                    "Registration Error:",
                    error
                );


                showMessage(

                    "Cannot connect to the Node.js server.",

                    "error"

                );


                registerButton.disabled =
                    false;


                registerButtonText.textContent =
                    "Create Account";

            }

        }

    );

}



// ==========================================
// LOGIN USER
// ==========================================

const loginForm =
    document.getElementById(
        "loginForm"
    );


if (loginForm) {


    // ======================================
    // EVENT LISTENER
    // Listens for login form submit
    // ======================================

    loginForm.addEventListener(

        "submit",

        async function (event) {


            // Prevent page refresh

            event.preventDefault();



            // Get login values

            const email =
                document
                    .getElementById(
                        "loginEmail"
                    )
                    .value
                    .trim()
                    .toLowerCase();


            const password =
                document
                    .getElementById(
                        "loginPassword"
                    )
                    .value;



            // Button elements

            const loginButton =
                document.getElementById(
                    "loginButton"
                );


            const loginButtonText =
                document.getElementById(
                    "loginButtonText"
                );



            // Disable login button

            loginButton.disabled = true;


            loginButtonText.textContent =
                "Signing In...";



            try {


                // ==================================
                // SEND LOGIN DATA TO NODE.JS
                // ==================================

                const response = await fetch(

                    "/api/login",

                    {

                        method: "POST",


                        headers: {

                            "Content-Type":
                                "application/json"

                        },


                        body: JSON.stringify({

                            email: email,

                            password: password

                        })

                    }

                );



                // Convert server response to JSON

                const data =
                    await response.json();



                // ==================================
                // LOGIN FAILED
                // ==================================

                if (!response.ok) {


                    showMessage(

                        data.message
                        ||
                        "Invalid email or password.",

                        "error"

                    );


                    loginButton.disabled =
                        false;


                    loginButtonText.textContent =
                        "Sign In";


                    return;

                }



                // ==================================
                // LOGIN SUCCESSFUL
                // ==================================


                // Save only current logged-in
                // user information in sessionStorage

                sessionStorage.setItem(

                    "taskflowCurrentUser",

                    JSON.stringify(
                        data.user
                    )

                );



                showMessage(

                    `Welcome back, ${data.user.name}!`,

                    "success"

                );



                // ==================================
                // TIMEOUT CALLBACK
                // Redirect after 1.5 seconds
                // ==================================

                setTimeout(() => {

                    window.location.href =
                        "dashboard.html";

                }, 1500);



            } catch (error) {


                console.error(
                    "Login Error:",
                    error
                );


                showMessage(

                    "Cannot connect to the Node.js server.",

                    "error"

                );


                loginButton.disabled =
                    false;


                loginButtonText.textContent =
                    "Sign In";

            }

        }

    );

}