// ==========================================
// IMPORT NODE.JS MODULES
// ==========================================

const http = require("http");
const fs = require("fs");
const path = require("path");
const EventEmitter = require("events");

// MongoDB Driver
const { MongoClient } = require("mongodb");


// ==========================================
// SERVER SETTINGS
// ==========================================

const PORT = 3001;


// ==========================================
// MONGODB SETTINGS
// ==========================================

const MONGO_URL =
    "mongodb://127.0.0.1:27017";

const DATABASE_NAME =
    "taskflowDB";


// Create MongoDB client
const client =
    new MongoClient(MONGO_URL);


// MongoDB collections
let usersCollection;
let tasksCollection;


// ==========================================
// NODE.JS EVENT EMITTER
// ==========================================

const appEvents =
    new EventEmitter();


// Event Listener - User Registered
appEvents.on(
    "userRegistered",
    (user) => {

        console.log(
            `EVENT: New user registered - ${user.name}`
        );

    }
);


// Event Listener - User Logged In
appEvents.on(
    "userLoggedIn",
    (user) => {

        console.log(
            `EVENT: User logged in - ${user.email}`
        );

    }
);


// Event Listener - Task Created
appEvents.on(
    "taskCreated",
    (task) => {

        console.log(
            `EVENT: Task created - ${task.title}`
        );

    }
);


// Event Listener - Task Updated
appEvents.on(
    "taskUpdated",
    (task) => {

        console.log(
            `EVENT: Task updated - ${task.title}`
        );

    }
);


// Event Listener - Task Deleted
appEvents.on(
    "taskDeleted",
    (taskId) => {

        console.log(
            `EVENT: Task deleted - ID ${taskId}`
        );

    }
);


// ==========================================
// CONNECT TO MONGODB
// ==========================================

async function connectDatabase() {

    try {

        // Connect to MongoDB
        await client.connect();


        // Select database
        const database =
            client.db(
                DATABASE_NAME
            );


        // Select collections
        usersCollection =
            database.collection(
                "users"
            );


        tasksCollection =
            database.collection(
                "tasks"
            );


        console.log("");
        console.log(
            "===================================="
        );

        console.log(
            " MongoDB Connected Successfully"
        );

        console.log(
            ` Database: ${DATABASE_NAME}`
        );

        console.log(
            " Collection: users"
        );

        console.log(
            " Collection: tasks"
        );

        console.log(
            "===================================="
        );


    } catch (error) {

        console.error(
            "MongoDB Connection Error:",
            error.message
        );


        // Stop application if database fails
        process.exit(1);

    }

}


// ==========================================
// SEND JSON RESPONSE
// ==========================================

function sendJSON(
    res,
    statusCode,
    data
) {

    res.writeHead(
        statusCode,
        {
            "Content-Type":
                "application/json"
        }
    );


    res.end(
        JSON.stringify(data)
    );

}


// ==========================================
// GET REQUEST BODY
// ==========================================

function getBody(req) {

    return new Promise(
        (resolve, reject) => {

            let body = "";


            // ==================================
            // NODE.JS EVENT LISTENER
            // ==================================

            req.on(
                "data",
                (chunk) => {

                    body +=
                        chunk.toString();

                }
            );


            // ==================================
            // NODE.JS EVENT LISTENER
            // ==================================

            req.on(
                "end",
                () => {

                    try {

                        resolve(

                            body

                                ? JSON.parse(
                                    body
                                )

                                : {}

                        );

                    } catch (error) {

                        reject(error);

                    }

                }
            );


            // ==================================
            // NODE.JS EVENT LISTENER
            // ==================================

            req.on(
                "error",
                (error) => {

                    reject(error);

                }
            );

        }
    );

}


// ==========================================
// SERVE HTML, CSS AND JS FILES
// ==========================================

function serveFile(
    req,
    res
) {

    let fileName =
        req.url;


    // Open login page by default
    if (
        fileName === "/"
    ) {

        fileName =
            "/index.html";

    }


    // Remove query parameters
    fileName =
        fileName.split("?")[0];


    const filePath =
        path.join(
            __dirname,
            fileName
        );


    const extension =
        path.extname(
            filePath
        );


    // File content types
    const contentTypes = {

        ".html":
            "text/html",

        ".css":
            "text/css",

        ".js":
            "text/javascript",

        ".json":
            "application/json",

        ".png":
            "image/png",

        ".jpg":
            "image/jpeg",

        ".jpeg":
            "image/jpeg",

        ".svg":
            "image/svg+xml",

        ".ico":
            "image/x-icon"

    };


    // ======================================
    // CALLBACK FUNCTION
    // ======================================

    fs.readFile(

        filePath,

        (error, content) => {


            if (error) {

                res.writeHead(
                    404,
                    {
                        "Content-Type":
                            "text/html"
                    }
                );


                res.end(
                    "<h1>404 - Page Not Found</h1>"
                );


                return;

            }


            res.writeHead(
                200,
                {
                    "Content-Type":

                        contentTypes[
                            extension
                        ]

                        ||

                        "text/plain"
                }
            );


            res.end(content);

        }

    );

}


// ==========================================
// CREATE NODE.JS HTTP SERVER
// ==========================================

const server =
    http.createServer(

        async (
            req,
            res
        ) => {


            const url =
                new URL(

                    req.url,

                    `http://${req.headers.host}`

                );


            const pathname =
                url.pathname;


            console.log(

                `${req.method} ${pathname}`

            );


            // ==================================
            // REGISTER USER
            // ==================================

            if (

                pathname ===
                    "/api/register"

                &&

                req.method ===
                    "POST"

            ) {

                try {


                    const body =
                        await getBody(
                            req
                        );


                    const name =
                        body.name
                            ?.trim();


                    const email =
                        body.email
                            ?.trim()
                            .toLowerCase();


                    const password =
                        body.password;


                    // Validate input
                    if (

                        !name

                        ||

                        !email

                        ||

                        !password

                    ) {

                        return sendJSON(

                            res,

                            400,

                            {
                                message:
                                    "All fields are required"
                            }

                        );

                    }


                    // Check whether email exists
                    const existingUser =

                        await usersCollection
                            .findOne(
                                {
                                    email:
                                        email
                                }
                            );


                    if (
                        existingUser
                    ) {

                        return sendJSON(

                            res,

                            409,

                            {
                                message:
                                    "Email already registered"
                            }

                        );

                    }


                    // Create user object
                    const newUser = {

                        id:
                            Date.now()
                                .toString(),

                        name:
                            name,

                        email:
                            email,

                        password:
                            password,

                        createdAt:
                            new Date()
                                .toISOString()

                    };


                    // ==================================
                    // INSERT USER INTO MONGODB
                    // ==================================

                    await usersCollection
                        .insertOne(
                            newUser
                        );


                    // ==================================
                    // EVENT EMITTER
                    // ==================================

                    appEvents.emit(

                        "userRegistered",

                        newUser

                    );


                    return sendJSON(

                        res,

                        201,

                        {
                            message:
                                "Registration successful"
                        }

                    );


                } catch (error) {


                    console.error(

                        "Registration Error:",

                        error

                    );


                    return sendJSON(

                        res,

                        500,

                        {
                            message:
                                "Registration failed"
                        }

                    );

                }

            }


            // ==================================
            // LOGIN USER
            // ==================================

            if (

                pathname ===
                    "/api/login"

                &&

                req.method ===
                    "POST"

            ) {

                try {


                    const body =
                        await getBody(
                            req
                        );


                    const email =
                        body.email
                            ?.trim()
                            .toLowerCase();


                    // ==================================
                    // FIND USER FROM MONGODB
                    // ==================================

                    const user =

                        await usersCollection
                            .findOne(

                                {

                                    email:
                                        email,

                                    password:
                                        body.password

                                }

                            );


                    if (
                        !user
                    ) {

                        return sendJSON(

                            res,

                            401,

                            {
                                message:
                                    "Invalid email or password"
                            }

                        );

                    }


                    // ==================================
                    // EVENT EMITTER
                    // ==================================

                    appEvents.emit(

                        "userLoggedIn",

                        user

                    );


                    return sendJSON(

                        res,

                        200,

                        {

                            message:
                                "Login successful",

                            user: {

                                id:
                                    user.id,

                                name:
                                    user.name,

                                email:
                                    user.email

                            }

                        }

                    );


                } catch (error) {


                    console.error(

                        "Login Error:",

                        error

                    );


                    return sendJSON(

                        res,

                        500,

                        {
                            message:
                                "Login failed"
                        }

                    );

                }

            }


            // ==================================
            // GET ALL TASKS OF LOGGED-IN USER
            // ==================================

            if (

                pathname ===
                    "/api/tasks"

                &&

                req.method ===
                    "GET"

            ) {

                try {


                    const userId =

                        url.searchParams
                            .get(
                                "userId"
                            );


                    // ==================================
                    // READ TASKS FROM MONGODB
                    // ==================================

                    const userTasks =

                        await tasksCollection

                            .find(
                                {
                                    userId:
                                        userId
                                }
                            )

                            .sort(
                                {
                                    createdAt:
                                        -1
                                }
                            )

                            .toArray();


                    return sendJSON(

                        res,

                        200,

                        userTasks

                    );


                } catch (error) {


                    console.error(

                        "Get Tasks Error:",

                        error

                    );


                    return sendJSON(

                        res,

                        500,

                        {
                            message:
                                "Unable to load tasks"
                        }

                    );

                }

            }


            // ==================================
            // CREATE TASK
            // ==================================

            if (

                pathname ===
                    "/api/tasks"

                &&

                req.method ===
                    "POST"

            ) {

                try {


                    const body =
                        await getBody(
                            req
                        );


                    // Validate task
                    if (
                        !body.title
                            ?.trim()
                    ) {

                        return sendJSON(

                            res,

                            400,

                            {
                                message:
                                    "Task title is required"
                            }

                        );

                    }


                    const newTask = {

                        id:
                            Date.now()
                                .toString(),

                        userId:
                            body.userId,

                        title:
                            body.title
                                .trim(),

                        description:
                            body.description
                            || "",

                        date:
                            body.date
                            || "",

                        priority:
                            body.priority
                            || "medium",

                        completed:
                            false,

                        createdAt:
                            new Date()
                                .toISOString()

                    };


                    // ==================================
                    // INSERT TASK INTO MONGODB
                    // ==================================

                    await tasksCollection
                        .insertOne(
                            newTask
                        );


                    // ==================================
                    // EVENT EMITTER
                    // ==================================

                    appEvents.emit(

                        "taskCreated",

                        newTask

                    );


                    return sendJSON(

                        res,

                        201,

                        newTask

                    );


                } catch (error) {


                    console.error(

                        "Create Task Error:",

                        error

                    );


                    return sendJSON(

                        res,

                        500,

                        {
                            message:
                                "Task creation failed"
                        }

                    );

                }

            }


            // ==================================
            // TASK ID ROUTES
            // ==================================

            const taskRoute =

                pathname.match(

                    /^\/api\/tasks\/(.+)$/

                );


            if (
                taskRoute
            ) {


                const taskId =
                    taskRoute[1];


                // ==============================
                // UPDATE TASK
                // ==============================

                if (
                    req.method ===
                    "PUT"
                ) {

                    try {


                        const body =
                            await getBody(
                                req
                            );


                        // Do not allow these fields
                        // to be changed from frontend
                        delete body._id;

                        delete body.id;

                        delete body.userId;


                        // ==================================
                        // UPDATE TASK IN MONGODB
                        // ==================================

                        const result =

                            await tasksCollection
                                .updateOne(

                                    {
                                        id:
                                            taskId
                                    },

                                    {
                                        $set:
                                            body
                                    }

                                );


                        if (
                            result.matchedCount
                            === 0
                        ) {

                            return sendJSON(

                                res,

                                404,

                                {
                                    message:
                                        "Task not found"
                                }

                            );

                        }


                        // Get updated task
                        const updatedTask =

                            await tasksCollection
                                .findOne(

                                    {
                                        id:
                                            taskId
                                    }

                                );


                        // ==================================
                        // EVENT EMITTER
                        // ==================================

                        appEvents.emit(

                            "taskUpdated",

                            updatedTask

                        );


                        return sendJSON(

                            res,

                            200,

                            updatedTask

                        );


                    } catch (error) {


                        console.error(

                            "Update Task Error:",

                            error

                        );


                        return sendJSON(

                            res,

                            500,

                            {
                                message:
                                    "Task update failed"
                            }

                        );

                    }

                }


                // ==============================
                // DELETE TASK
                // ==============================

                if (
                    req.method ===
                    "DELETE"
                ) {

                    try {


                        // ==================================
                        // DELETE TASK FROM MONGODB
                        // ==================================

                        const result =

                            await tasksCollection
                                .deleteOne(

                                    {
                                        id:
                                            taskId
                                    }

                                );


                        if (
                            result.deletedCount
                            === 0
                        ) {

                            return sendJSON(

                                res,

                                404,

                                {
                                    message:
                                        "Task not found"
                                }

                            );

                        }


                        // ==================================
                        // EVENT EMITTER
                        // ==================================

                        appEvents.emit(

                            "taskDeleted",

                            taskId

                        );


                        return sendJSON(

                            res,

                            200,

                            {
                                message:
                                    "Task deleted successfully"
                            }

                        );


                    } catch (error) {


                        console.error(

                            "Delete Task Error:",

                            error

                        );


                        return sendJSON(

                            res,

                            500,

                            {
                                message:
                                    "Task deletion failed"
                            }

                        );

                    }

                }

            }


            // ==================================
            // SERVE FRONTEND FILES
            // ==================================

            serveFile(
                req,
                res
            );

        }

    );


// ==========================================
// SERVER ERROR EVENT LISTENER
// ==========================================

server.on(
    "error",
    (error) => {


        if (
            error.code ===
            "EADDRINUSE"
        ) {

            console.log(
                `Port ${PORT} is already in use.`
            );

            console.log(
                "Stop the other server or change the port."
            );

        } else {

            console.error(
                "Server Error:",
                error
            );

        }

    }
);


// ==========================================
// START APPLICATION
// ==========================================

async function startApplication() {

    try {


        // ==================================
        // FIRST CONNECT TO MONGODB
        // ==================================

        await connectDatabase();


        // ==================================
        // THEN START NODE.JS SERVER
        // ==================================

        server.listen(

            PORT,

            () => {


                console.log("");
                console.log(
                    "===================================="
                );

                console.log(
                    " TASKFLOW SERVER STARTED"
                );

                console.log(
                    ` Running at: http://localhost:${PORT}`
                );

                console.log(
                    "===================================="
                );

                console.log(
                    " Node.js         : YES"
                );

                console.log(
                    " MongoDB         : YES"
                );

                console.log(
                    " EventEmitter    : YES"
                );

                console.log(
                    " Event Listeners : YES"
                );

                console.log(
                    " Callback        : YES"
                );

                console.log(
                    " Timeout Callback: YES"
                );

                console.log(
                    " Express.js      : NO"
                );

                console.log(
                    "===================================="
                );


                // ==================================
                // TIMEOUT CALLBACK
                // ==================================

                setTimeout(

                    () => {

                        console.log(
                            "Timeout Callback: Server and MongoDB are running successfully!"
                        );

                    },

                    2000

                );

            }

        );


    } catch (error) {


        console.error(

            "Application Startup Error:",

            error

        );

    }

}


// Start application
startApplication();