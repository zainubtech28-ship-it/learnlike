// ==========================================
// TASKFLOW DASHBOARD JAVASCRIPT
// ==========================================


// ==========================================
// CHECK LOGGED-IN USER
// ==========================================

const currentUser = JSON.parse(
    sessionStorage.getItem("taskflowCurrentUser")
);


// If no user is logged in, go to login page
if (!currentUser) {

    window.location.href = "index.html";

}


// ==========================================
// GLOBAL VARIABLES
// ==========================================

let tasks = [];

let currentFilter = "all";

let editingTaskId = null;

let taskToDeleteId = null;


// ==========================================
// GET HTML ELEMENTS
// ==========================================

const taskList =
    document.getElementById("taskList");

const emptyState =
    document.getElementById("emptyState");

const loadingState =
    document.getElementById("loadingState");

const taskModal =
    document.getElementById("taskModal");

const deleteModal =
    document.getElementById("deleteModal");

const taskForm =
    document.getElementById("taskForm");

const searchInput =
    document.getElementById("searchInput");

const openModalBtn =
    document.getElementById("openModalBtn");

const emptyAddTaskBtn =
    document.getElementById("emptyAddTaskBtn");

const closeModalBtn =
    document.getElementById("closeModalBtn");

const cancelModalBtn =
    document.getElementById("cancelModalBtn");

const cancelDeleteBtn =
    document.getElementById("cancelDeleteBtn");

const confirmDeleteBtn =
    document.getElementById("confirmDeleteBtn");

const logoutBtn =
    document.getElementById("logoutBtn");


// ==========================================
// DISPLAY USER INFORMATION
// ==========================================

if (currentUser) {

    const firstName =
        currentUser.name.split(" ")[0];


    document.getElementById(
        "userName"
    ).textContent = firstName;


    document.getElementById(
        "profileName"
    ).textContent = currentUser.name;


    document.getElementById(
        "profileEmail"
    ).textContent = currentUser.email;


    document.getElementById(
        "sidebarUserName"
    ).textContent = firstName;


    const firstLetter =
        currentUser.name
            .charAt(0)
            .toUpperCase();


    document.getElementById(
        "userAvatar"
    ).textContent = firstLetter;


    document.getElementById(
        "sidebarAvatar"
    ).textContent = firstLetter;

}


// ==========================================
// DISPLAY CURRENT DATE
// ==========================================

const dateOptions = {

    weekday: "long",

    year: "numeric",

    month: "long",

    day: "numeric"

};


document.getElementById(
    "currentDate"
).textContent =

    new Date()
        .toLocaleDateString(
            "en-US",
            dateOptions
        );


// ==========================================
// ESCAPE HTML
// Prevent HTML injection
// ==========================================

function escapeHTML(text) {

    const div =
        document.createElement("div");

    div.textContent =
        text || "";

    return div.innerHTML;

}


// ==========================================
// SHOW TOAST MESSAGE
// ==========================================

function showToast(
    message,
    type = "success"
) {

    const toast =
        document.getElementById("toast");


    toast.textContent = message;


    toast.className =
        `toast show ${type}`;


    // ======================================
    // TIMEOUT CALLBACK
    // Hide notification after 3 seconds
    // ======================================

    setTimeout(() => {

        toast.className = "toast";

    }, 3000);

}


// ==========================================
// LOAD TASKS FROM NODE.JS SERVER
// ==========================================

async function loadTasks() {

    try {

        loadingState.style.display =
            "flex";


        emptyState.style.display =
            "none";


        const response = await fetch(

            `/api/tasks?userId=${encodeURIComponent(
                currentUser.id
            )}`

        );


        if (!response.ok) {

            throw new Error(
                "Unable to load tasks"
            );

        }


        tasks =
            await response.json();


        loadingState.style.display =
            "none";


        renderTasks();


    } catch (error) {


        console.error(
            "Load Tasks Error:",
            error
        );


        loadingState.style.display =
            "none";


        showToast(
            "Unable to load your tasks.",
            "error"
        );

    }

}


// ==========================================
// RENDER TASKS
// ==========================================

function renderTasks() {


    const searchText =
        searchInput
            .value
            .trim()
            .toLowerCase();



    // Filter tasks

    const filteredTasks =
        tasks.filter((task) => {


            const title =
                task.title
                    ?.toLowerCase()
                    || "";


            const description =
                task.description
                    ?.toLowerCase()
                    || "";


            // Search condition

            const matchesSearch =

                title.includes(searchText)

                ||

                description.includes(
                    searchText
                );



            // Filter condition

            let matchesFilter = true;


            if (
                currentFilter ===
                "pending"
            ) {

                matchesFilter =
                    !task.completed;

            }


            if (
                currentFilter ===
                "completed"
            ) {

                matchesFilter =
                    task.completed;

            }


            return (
                matchesSearch
                &&
                matchesFilter
            );

        });



    // Clear existing task cards

    taskList.innerHTML = "";



    // Show empty state

    if (
        filteredTasks.length === 0
    ) {

        emptyState.style.display =
            "flex";

    } else {

        emptyState.style.display =
            "none";

    }



    // Create task cards

    filteredTasks.forEach(
        (task) => {


            const taskCard =
                document.createElement(
                    "div"
                );


            taskCard.className =

                `task-card ${
                    task.completed
                        ? "task-completed"
                        : ""
                }`;



            taskCard.innerHTML = `

                <button
                    class="task-check"
                    data-action="toggle"
                    data-id="${task.id}"
                    title="${
                        task.completed
                            ? "Mark as pending"
                            : "Mark as completed"
                    }"
                >

                    ${
                        task.completed
                            ? "✓"
                            : ""
                    }

                </button>


                <div class="task-content">


                    <div class="task-top">


                        <div class="task-main-info">


                            <h3>

                                ${escapeHTML(
                                    task.title
                                )}

                            </h3>


                            <p>

                                ${
                                    escapeHTML(
                                        task.description
                                        ||
                                        "No description added."
                                    )
                                }

                            </p>


                        </div>


                        <span
                            class="priority-badge ${
                                task.priority
                            }"
                        >

                            ${
                                escapeHTML(
                                    task.priority
                                )
                            }

                        </span>


                    </div>



                    <div class="task-bottom">


                        <span class="task-date">

                            📅

                            ${formatDate(
                                task.date
                            )}

                        </span>



                        <div class="task-actions">


                            <button
                                class="edit-btn"
                                data-action="edit"
                                data-id="${task.id}"
                                title="Edit task"
                            >

                                ✎

                            </button>


                            <button
                                class="delete-btn"
                                data-action="delete"
                                data-id="${task.id}"
                                title="Delete task"
                            >

                                🗑

                            </button>


                        </div>


                    </div>


                </div>

            `;


            taskList.appendChild(
                taskCard
            );

        }
    );


    updateStatistics();

}


// ==========================================
// FORMAT TASK DATE
// ==========================================

function formatDate(date) {

    if (!date) {

        return "No due date";

    }


    const taskDate =
        new Date(
            `${date}T00:00:00`
        );


    return taskDate
        .toLocaleDateString(

            "en-US",

            {

                month: "short",

                day: "numeric",

                year: "numeric"

            }

        );

}


// ==========================================
// UPDATE DASHBOARD STATISTICS
// ==========================================

function updateStatistics() {


    const total =
        tasks.length;


    const completed =
        tasks.filter(
            (task) =>
                task.completed
        ).length;


    const pending =
        total - completed;


    const percentage =

        total === 0

            ? 0

            : Math.round(

                (
                    completed
                    /
                    total
                )
                *
                100

            );



    document.getElementById(
        "totalTasks"
    ).textContent = total;


    document.getElementById(
        "pendingTasks"
    ).textContent = pending;


    document.getElementById(
        "completedTasks"
    ).textContent = completed;


    document.getElementById(
        "progressPercentage"
    ).textContent =
        `${percentage}%`;



    // Update circular progress

    const progressCircle =
        document.querySelector(
            ".progress-circle"
        );


    progressCircle.style.background =

        `conic-gradient(
            #7157f5 ${percentage}%,
            #ececf4 ${percentage}%
        )`;



    // Update progress message

    const progressText =
        document.getElementById(
            "progressText"
        );


    if (
        total > 0
        &&
        percentage === 100
    ) {

        progressText.textContent =
            "All done! 🎉";

    } else if (
        percentage >= 75
    ) {

        progressText.textContent =
            "Almost there!";

    } else if (
        percentage >= 50
    ) {

        progressText.textContent =
            "Great progress!";

    } else {

        progressText.textContent =
            "Keep going!";

    }

}


// ==========================================
// OPEN CREATE TASK MODAL
// ==========================================

function openTaskModal() {


    editingTaskId = null;


    taskForm.reset();


    document.getElementById(
        "taskPriority"
    ).value = "medium";


    document.getElementById(
        "modalTitle"
    ).textContent =
        "Create New Task";


    document.getElementById(
        "saveButtonText"
    ).textContent =
        "Create Task";


    taskModal.classList.add(
        "show"
    );


    // Timeout callback used to focus input
    // after modal animation finishes

    setTimeout(() => {

        document.getElementById(
            "taskTitle"
        ).focus();

    }, 200);

}


// ==========================================
// CLOSE TASK MODAL
// ==========================================

function closeTaskModal() {

    taskModal.classList.remove(
        "show"
    );


    editingTaskId = null;


    taskForm.reset();

}


// ==========================================
// CREATE OR UPDATE TASK
// ==========================================

taskForm.addEventListener(

    "submit",

    async function (event) {


        event.preventDefault();



        const title =
            document
                .getElementById(
                    "taskTitle"
                )
                .value
                .trim();


        const description =
            document
                .getElementById(
                    "taskDescription"
                )
                .value
                .trim();


        const date =
            document
                .getElementById(
                    "taskDate"
                )
                .value;


        const priority =
            document
                .getElementById(
                    "taskPriority"
                )
                .value;


        const saveTaskBtn =
            document.getElementById(
                "saveTaskBtn"
            );


        const saveButtonText =
            document.getElementById(
                "saveButtonText"
            );



        if (!title) {

            showToast(
                "Please enter a task title.",
                "error"
            );

            return;

        }



        saveTaskBtn.disabled = true;


        saveButtonText.textContent =

            editingTaskId

                ? "Updating..."

                : "Creating...";



        try {


            // ==================================
            // EDIT EXISTING TASK
            // ==================================

            if (editingTaskId) {


                const response = await fetch(

                    `/api/tasks/${editingTaskId}`,

                    {

                        method: "PUT",


                        headers: {

                            "Content-Type":
                                "application/json"

                        },


                        body: JSON.stringify({

                            title,

                            description,

                            date,

                            priority

                        })

                    }

                );


                if (!response.ok) {

                    throw new Error(
                        "Task update failed"
                    );

                }


                const updatedTask =
                    await response.json();



                const taskIndex =
                    tasks.findIndex(

                        (task) =>
                            task.id ===
                            editingTaskId

                    );


                if (
                    taskIndex !== -1
                ) {

                    tasks[taskIndex] =
                        updatedTask;

                }


                showToast(
                    "Task updated successfully!"
                );


            } else {


                // ==================================
                // CREATE NEW TASK
                // ==================================

                const response = await fetch(

                    "/api/tasks",

                    {

                        method: "POST",


                        headers: {

                            "Content-Type":
                                "application/json"

                        },


                        body: JSON.stringify({

                            userId:
                                currentUser.id,

                            title,

                            description,

                            date,

                            priority

                        })

                    }

                );


                if (!response.ok) {

                    throw new Error(
                        "Task creation failed"
                    );

                }


                const newTask =
                    await response.json();


                tasks.unshift(
                    newTask
                );


                showToast(
                    "New task created successfully!"
                );

            }



            closeTaskModal();


            renderTasks();



        } catch (error) {


            console.error(
                "Save Task Error:",
                error
            );


            showToast(
                "Unable to save task.",
                "error"
            );


        } finally {


            saveTaskBtn.disabled =
                false;


            saveButtonText.textContent =

                editingTaskId

                    ? "Update Task"

                    : "Create Task";

        }

    }

);


// ==========================================
// EDIT TASK
// ==========================================

function editTask(taskId) {


    const task =
        tasks.find(

            (task) =>
                task.id === taskId

        );


    if (!task) {

        return;

    }


    editingTaskId =
        taskId;



    // Fill form with task data

    document.getElementById(
        "taskTitle"
    ).value =
        task.title || "";


    document.getElementById(
        "taskDescription"
    ).value =
        task.description || "";


    document.getElementById(
        "taskDate"
    ).value =
        task.date || "";


    document.getElementById(
        "taskPriority"
    ).value =
        task.priority || "medium";



    document.getElementById(
        "modalTitle"
    ).textContent =
        "Edit Task";


    document.getElementById(
        "saveButtonText"
    ).textContent =
        "Update Task";



    taskModal.classList.add(
        "show"
    );

}


// ==========================================
// TOGGLE TASK STATUS
// ==========================================

async function toggleTask(taskId) {


    const task =
        tasks.find(

            (task) =>
                task.id === taskId

        );


    if (!task) {

        return;

    }



    try {


        const response = await fetch(

            `/api/tasks/${taskId}`,

            {

                method: "PUT",


                headers: {

                    "Content-Type":
                        "application/json"

                },


                body: JSON.stringify({

                    completed:
                        !task.completed

                })

            }

        );


        if (!response.ok) {

            throw new Error(
                "Status update failed"
            );

        }


        const updatedTask =
            await response.json();



        const taskIndex =
            tasks.findIndex(

                (task) =>
                    task.id === taskId

            );


        if (
            taskIndex !== -1
        ) {

            tasks[taskIndex] =
                updatedTask;

        }



        renderTasks();



        showToast(

            updatedTask.completed

                ? "Great job! Task completed 🎉"

                : "Task moved back to pending."

        );


    } catch (error) {


        console.error(
            "Toggle Task Error:",
            error
        );


        showToast(
            "Unable to update task.",
            "error"
        );

    }

}


// ==========================================
// OPEN DELETE CONFIRMATION
// ==========================================

function openDeleteModal(taskId) {


    taskToDeleteId =
        taskId;


    deleteModal.classList.add(
        "show"
    );

}


// ==========================================
// CLOSE DELETE CONFIRMATION
// ==========================================

function closeDeleteModal() {


    deleteModal.classList.remove(
        "show"
    );


    taskToDeleteId =
        null;

}


// ==========================================
// DELETE TASK
// ==========================================

async function deleteTask() {


    if (!taskToDeleteId) {

        return;

    }


    const deletingId =
        taskToDeleteId;



    try {


        confirmDeleteBtn.disabled =
            true;


        confirmDeleteBtn.textContent =
            "Deleting...";



        const response = await fetch(

            `/api/tasks/${deletingId}`,

            {

                method: "DELETE"

            }

        );


        if (!response.ok) {

            throw new Error(
                "Task deletion failed"
            );

        }



        tasks =
            tasks.filter(

                (task) =>
                    task.id !==
                    deletingId

            );



        closeDeleteModal();


        renderTasks();


        showToast(
            "Task deleted successfully."
        );


    } catch (error) {


        console.error(
            "Delete Task Error:",
            error
        );


        showToast(
            "Unable to delete task.",
            "error"
        );


    } finally {


        confirmDeleteBtn.disabled =
            false;


        confirmDeleteBtn.textContent =
            "Delete Task";

    }

}


// ==========================================
// TASK LIST EVENT LISTENER
// EVENT DELEGATION
// ==========================================

taskList.addEventListener(

    "click",

    function (event) {


        const button =
            event.target.closest(
                "button[data-action]"
            );


        if (!button) {

            return;

        }


        const action =
            button.dataset.action;


        const taskId =
            button.dataset.id;



        if (
            action === "toggle"
        ) {

            toggleTask(taskId);

        }


        if (
            action === "edit"
        ) {

            editTask(taskId);

        }


        if (
            action === "delete"
        ) {

            openDeleteModal(taskId);

        }

    }

);


// ==========================================
// SEARCH EVENT LISTENER
// ==========================================

searchInput.addEventListener(

    "input",

    function () {

        renderTasks();

    }

);


// ==========================================
// FILTER BUTTON EVENT LISTENERS
// ==========================================

document
    .querySelectorAll(
        ".filter-btn"
    )
    .forEach(

        function (button) {


            button.addEventListener(

                "click",

                function () {


                    document
                        .querySelectorAll(
                            ".filter-btn"
                        )
                        .forEach(

                            function (btn) {

                                btn.classList.remove(
                                    "active"
                                );

                            }

                        );


                    button.classList.add(
                        "active"
                    );


                    currentFilter =
                        button.dataset.filter;


                    renderTasks();

                }

            );

        }

    );


// ==========================================
// SIDEBAR NAVIGATION EVENT LISTENERS
// ==========================================

document
    .querySelectorAll(
        ".nav-item"
    )
    .forEach(

        function (button) {


            button.addEventListener(

                "click",

                function () {


                    document
                        .querySelectorAll(
                            ".nav-item"
                        )
                        .forEach(

                            function (btn) {

                                btn.classList.remove(
                                    "active"
                                );

                            }

                        );


                    button.classList.add(
                        "active"
                    );


                    currentFilter =
                        button.dataset.filter;


                    renderTasks();

                }

            );

        }

    );


// ==========================================
// MODAL EVENT LISTENERS
// ==========================================

openModalBtn.addEventListener(

    "click",

    function () {

        openTaskModal();

    }

);


emptyAddTaskBtn.addEventListener(

    "click",

    function () {

        openTaskModal();

    }

);


closeModalBtn.addEventListener(

    "click",

    function () {

        closeTaskModal();

    }

);


cancelModalBtn.addEventListener(

    "click",

    function () {

        closeTaskModal();

    }

);


// Close modal when clicking outside

taskModal.addEventListener(

    "click",

    function (event) {


        if (
            event.target === taskModal
        ) {

            closeTaskModal();

        }

    }

);


// ==========================================
// DELETE MODAL EVENT LISTENERS
// ==========================================

cancelDeleteBtn.addEventListener(

    "click",

    function () {

        closeDeleteModal();

    }

);


confirmDeleteBtn.addEventListener(

    "click",

    function () {

        deleteTask();

    }

);


deleteModal.addEventListener(

    "click",

    function (event) {


        if (
            event.target ===
            deleteModal
        ) {

            closeDeleteModal();

        }

    }

);


// ==========================================
// KEYBOARD EVENT LISTENER
// ==========================================

document.addEventListener(

    "keydown",

    function (event) {


        if (
            event.key === "Escape"
        ) {


            closeTaskModal();


            closeDeleteModal();

        }

    }

);


// ==========================================
// LOGOUT EVENT LISTENER
// ==========================================

logoutBtn.addEventListener(

    "click",

    function () {


        const confirmLogout =
            confirm(
                "Are you sure you want to logout?"
            );


        if (!confirmLogout) {

            return;

        }


        // Remove logged-in user session

        sessionStorage.removeItem(
            "taskflowCurrentUser"
        );


        showToast(
            "Logging out..."
        );


        // ==================================
        // TIMEOUT CALLBACK
        // ==================================

        setTimeout(() => {

            window.location.href =
                "index.html";

        }, 800);

    }

);


// ==========================================
// INITIALIZE DASHBOARD
// ==========================================

// Load tasks when the page opens
loadTasks();